#!/bin/bash
#starter mac
cd /Users/mohamadnaim/Documents/pyreq
chmod +x ssl.sh 

#if 1--> mac refresh
#if 2--> server refresh
./ssl.sh 1 "MacOS (m3u8 update)"