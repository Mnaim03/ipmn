#!/bin/bash
#starter linux
cd #percorso
chmod +x ssl.sh 

#if 1--> mac refresh
#if 2--> server refresh
./ssl.sh 2 "Linux Server (m3u8 update)"